var bananaImage,
obstacleImage,
obstaclegroup,
backdrop,
score;

function preload(){
backImage=loadImage("jungle.jpj");
player_running=loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
bananaImage=loadImage("banana.png");
obstacle_img=loadImage("stone.png");
}

function setup() {
  createCanvas(400, 400);
  
  backdrop=createSprite(200,200,400,400);
  backdrop.addImage("moving_backdrop",backImage);
  backdrop.x=backdrop.width/2;
  backdrop.velocityX=-2;
  
  ground=createSprite(200,380,400,10);
  ground.visible=false;
  
  player=createSprite(50,360)
  player.addAnimation("walk",player_running);
  player.scale=0.5;
}

function draw() {
  background(220);
  
  if(backdrop.x<0){
  backdrop.x=backdrop.width/2;}
    
  if(foodgroup.isTouching(player)){
  player.destroy(food);
  score=score+2;
  }
  
}